create temporary table pgdump_restore_path(p text);
--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
-- Edit the following to match the path where the
-- tar archive has been extracted.
--
insert into pgdump_restore_path values('/tmp');

--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

DROP INDEX public.unique_schema_migrations;
ALTER TABLE ONLY public.user_lists DROP CONSTRAINT user_lists_pkey;
ALTER TABLE ONLY public.user_groups DROP CONSTRAINT user_groups_pkey;
ALTER TABLE ONLY public.transaction_type_details DROP CONSTRAINT transaction_type_details_pkey;
ALTER TABLE ONLY public.transaction_headers DROP CONSTRAINT transaction_headers_pkey;
ALTER TABLE ONLY public.transaction_allocations DROP CONSTRAINT transaction_allocations_pkey;
ALTER TABLE ONLY public.to_do_lists DROP CONSTRAINT to_do_lists_pkey;
ALTER TABLE ONLY public.tags DROP CONSTRAINT tags_pkey;
ALTER TABLE ONLY public.tag_types DROP CONSTRAINT tag_types_pkey;
ALTER TABLE ONLY public.tag_meta_types DROP CONSTRAINT tag_meta_types_pkey;
ALTER TABLE ONLY public.system_news DROP CONSTRAINT system_news_pkey;
ALTER TABLE ONLY public.system_logs DROP CONSTRAINT system_logs_pkey;
ALTER TABLE ONLY public.sources DROP CONSTRAINT sources_pkey;
ALTER TABLE ONLY public.simple_captcha_data DROP CONSTRAINT simple_captcha_data_pkey;
ALTER TABLE ONLY public.roles DROP CONSTRAINT roles_pkey;
ALTER TABLE ONLY public.role_conditions DROP CONSTRAINT role_conditions_pkey;
ALTER TABLE ONLY public.relationships DROP CONSTRAINT relationships_pkey;
ALTER TABLE ONLY public.receipt_methods DROP CONSTRAINT receipt_methods_pkey;
ALTER TABLE ONLY public.receipt_accounts DROP CONSTRAINT receipt_accounts_pkey;
ALTER TABLE ONLY public.query_headers DROP CONSTRAINT query_headers_pkey;
ALTER TABLE ONLY public.query_details DROP CONSTRAINT query_details_pkey;
ALTER TABLE ONLY public.query_criterias DROP CONSTRAINT query_criterias_pkey;
ALTER TABLE ONLY public.potential_members DROP CONSTRAINT potential_members_pkey;
ALTER TABLE ONLY public.postcodes DROP CONSTRAINT postcodes_pkey;
ALTER TABLE ONLY public.post_areas DROP CONSTRAINT post_areas_pkey;
ALTER TABLE ONLY public.person_roles DROP CONSTRAINT person_roles_pkey;
ALTER TABLE ONLY public.person_groups DROP CONSTRAINT person_groups_pkey;
ALTER TABLE ONLY public.person_bank_accounts DROP CONSTRAINT person_bank_accounts_pkey;
ALTER TABLE ONLY public.people DROP CONSTRAINT people_pkey;
ALTER TABLE ONLY public.organisations DROP CONSTRAINT organisations_pkey;
ALTER TABLE ONLY public.organisation_subsidiaries DROP CONSTRAINT organisation_subsidiaries_pkey;
ALTER TABLE ONLY public.organisation_relationships DROP CONSTRAINT organisation_relationships_pkey;
ALTER TABLE ONLY public.organisation_key_personnels DROP CONSTRAINT organisation_key_personnels_pkey;
ALTER TABLE ONLY public.organisation_hierarchies DROP CONSTRAINT organisation_hierarchies_pkey;
ALTER TABLE ONLY public.organisation_groups DROP CONSTRAINT organisation_groups_pkey;
ALTER TABLE ONLY public.notes DROP CONSTRAINT notes_pkey;
ALTER TABLE ONLY public.message_templates DROP CONSTRAINT message_templates_pkey;
ALTER TABLE ONLY public.master_docs DROP CONSTRAINT master_docs_pkey;
ALTER TABLE ONLY public.login_accounts DROP CONSTRAINT login_accounts_pkey;
ALTER TABLE ONLY public.list_headers DROP CONSTRAINT list_headers_pkey;
ALTER TABLE ONLY public.list_details DROP CONSTRAINT list_details_pkey;
ALTER TABLE ONLY public.languages DROP CONSTRAINT languages_pkey;
ALTER TABLE ONLY public.keywords DROP CONSTRAINT keywords_pkey;
ALTER TABLE ONLY public.keyword_links DROP CONSTRAINT keyword_links_pkey;
ALTER TABLE ONLY public.images DROP CONSTRAINT images_pkey;
ALTER TABLE ONLY public.groups DROP CONSTRAINT groups_pkey;
ALTER TABLE ONLY public.group_permissions DROP CONSTRAINT group_permissions_pkey;
ALTER TABLE ONLY public.group_lists DROP CONSTRAINT group_lists_pkey;
ALTER TABLE ONLY public.grids DROP CONSTRAINT grids_pkey;
ALTER TABLE ONLY public.feedback_items DROP CONSTRAINT feedback_items_pkey;
ALTER TABLE ONLY public.employments DROP CONSTRAINT employments_pkey;
ALTER TABLE ONLY public.duplication_formulas DROP CONSTRAINT duplication_formulas_pkey;
ALTER TABLE ONLY public.duplication_formula_details DROP CONSTRAINT duplication_formula_details_pkey;
ALTER TABLE ONLY public.dashboard_preferences DROP CONSTRAINT dashboard_preferences_pkey;
ALTER TABLE ONLY public.countries DROP CONSTRAINT countries_pkey;
ALTER TABLE ONLY public.contacts DROP CONSTRAINT contacts_pkey;
ALTER TABLE ONLY public.compile_lists DROP CONSTRAINT compile_lists_pkey;
ALTER TABLE ONLY public.client_setups DROP CONSTRAINT client_setups_pkey;
ALTER TABLE ONLY public.bank_accounts DROP CONSTRAINT client_bank_accounts_pkey;
ALTER TABLE ONLY public.campaigns DROP CONSTRAINT campaigns_pkey;
ALTER TABLE ONLY public.bulk_emails DROP CONSTRAINT bulk_emails_pkey;
ALTER TABLE ONLY public.bdrb_job_queues DROP CONSTRAINT bdrb_job_queues_pkey;
ALTER TABLE ONLY public.banks DROP CONSTRAINT banks_pkey;
ALTER TABLE ONLY public.bank_grids DROP CONSTRAINT bank_grids_pkey;
ALTER TABLE ONLY public.available_modules DROP CONSTRAINT available_modules_pkey;
ALTER TABLE ONLY public.amazon_settings DROP CONSTRAINT amazon_settings_pkey;
ALTER TABLE ONLY public.allocation_types DROP CONSTRAINT allocation_types_pkey;
ALTER TABLE ONLY public.addresses DROP CONSTRAINT addresses_pkey;
ALTER TABLE public.user_lists ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.user_groups ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.transaction_type_details ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.transaction_headers ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.transaction_allocations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.to_do_lists ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.tags ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.tag_types ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.tag_meta_types ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.system_news ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.system_logs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.sources ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.simple_captcha_data ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.roles ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.role_conditions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.relationships ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.receipt_methods ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.receipt_accounts ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.query_headers ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.query_details ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.query_criterias ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.potential_members ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.postcodes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.post_areas ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.person_roles ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.person_groups ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.person_bank_accounts ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.people ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.organisations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.organisation_subsidiaries ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.organisation_relationships ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.organisation_key_personnels ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.organisation_hierarchies ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.organisation_groups ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.notes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.message_templates ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.master_docs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.login_accounts ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.list_headers ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.list_details ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.languages ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.keywords ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.keyword_links ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.images ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.groups ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.group_permissions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.group_lists ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.grids ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.feedback_items ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.employments ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.duplication_formulas ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.duplication_formula_details ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.dashboard_preferences ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.countries ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.contacts ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.compile_lists ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.client_setups ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.campaigns ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.bulk_emails ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.bdrb_job_queues ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.banks ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.bank_grids ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.bank_accounts ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.available_modules ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.amazon_settings ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.allocation_types ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.addresses ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.user_lists_id_seq;
DROP TABLE public.user_lists;
DROP SEQUENCE public.user_groups_id_seq;
DROP TABLE public.user_groups;
DROP SEQUENCE public.transaction_type_details_id_seq;
DROP TABLE public.transaction_type_details;
DROP SEQUENCE public.transaction_headers_id_seq;
DROP TABLE public.transaction_headers;
DROP SEQUENCE public.transaction_allocations_id_seq;
DROP TABLE public.transaction_allocations;
DROP SEQUENCE public.to_do_lists_id_seq;
DROP TABLE public.to_do_lists;
DROP SEQUENCE public.tags_id_seq;
DROP TABLE public.tags;
DROP SEQUENCE public.tag_types_id_seq;
DROP TABLE public.tag_types;
DROP SEQUENCE public.tag_meta_types_id_seq;
DROP TABLE public.tag_meta_types;
DROP SEQUENCE public.system_news_id_seq;
DROP TABLE public.system_news;
DROP SEQUENCE public.system_logs_id_seq;
DROP TABLE public.system_logs;
DROP SEQUENCE public.sources_id_seq;
DROP TABLE public.sources;
DROP SEQUENCE public.simple_captcha_data_id_seq;
DROP TABLE public.simple_captcha_data;
DROP TABLE public.schema_migrations;
DROP SEQUENCE public.roles_id_seq;
DROP TABLE public.roles;
DROP SEQUENCE public.role_conditions_id_seq;
DROP TABLE public.role_conditions;
DROP SEQUENCE public.relationships_id_seq;
DROP TABLE public.relationships;
DROP SEQUENCE public.receipt_methods_id_seq;
DROP TABLE public.receipt_methods;
DROP SEQUENCE public.receipt_accounts_id_seq;
DROP TABLE public.receipt_accounts;
DROP SEQUENCE public.query_headers_id_seq;
DROP TABLE public.query_headers;
DROP SEQUENCE public.query_details_id_seq;
DROP TABLE public.query_details;
DROP SEQUENCE public.query_criterias_id_seq;
DROP TABLE public.query_criterias;
DROP SEQUENCE public.potential_members_id_seq;
DROP TABLE public.potential_members;
DROP SEQUENCE public.postcodes_id_seq;
DROP TABLE public.postcodes;
DROP SEQUENCE public.post_areas_id_seq;
DROP TABLE public.post_areas;
DROP SEQUENCE public.person_roles_id_seq;
DROP TABLE public.person_roles;
DROP SEQUENCE public.person_groups_id_seq;
DROP TABLE public.person_groups;
DROP SEQUENCE public.person_bank_accounts_id_seq;
DROP TABLE public.person_bank_accounts;
DROP SEQUENCE public.people_id_seq;
DROP TABLE public.people;
DROP SEQUENCE public.organisations_id_seq;
DROP TABLE public.organisations;
DROP SEQUENCE public.organisation_subsidiaries_id_seq;
DROP TABLE public.organisation_subsidiaries;
DROP SEQUENCE public.organisation_relationships_id_seq;
DROP TABLE public.organisation_relationships;
DROP SEQUENCE public.organisation_key_personnels_id_seq;
DROP TABLE public.organisation_key_personnels;
DROP SEQUENCE public.organisation_hierarchies_id_seq;
DROP TABLE public.organisation_hierarchies;
DROP SEQUENCE public.organisation_groups_id_seq;
DROP TABLE public.organisation_groups;
DROP SEQUENCE public.notes_id_seq;
DROP TABLE public.notes;
DROP SEQUENCE public.message_templates_id_seq;
DROP TABLE public.message_templates;
DROP SEQUENCE public.master_docs_id_seq;
DROP TABLE public.master_docs;
DROP SEQUENCE public.login_accounts_id_seq;
DROP TABLE public.login_accounts;
DROP SEQUENCE public.list_headers_id_seq;
DROP TABLE public.list_headers;
DROP SEQUENCE public.list_details_id_seq;
DROP TABLE public.list_details;
DROP SEQUENCE public.languages_id_seq;
DROP TABLE public.languages;
DROP SEQUENCE public.keywords_id_seq;
DROP TABLE public.keywords;
DROP SEQUENCE public.keyword_links_id_seq;
DROP TABLE public.keyword_links;
DROP SEQUENCE public.images_id_seq;
DROP TABLE public.images;
DROP SEQUENCE public.groups_id_seq;
DROP TABLE public.groups;
DROP SEQUENCE public.group_permissions_id_seq;
DROP TABLE public.group_permissions;
DROP SEQUENCE public.group_lists_id_seq;
DROP TABLE public.group_lists;
DROP SEQUENCE public.grids_id_seq;
DROP TABLE public.grids;
DROP SEQUENCE public.feedback_items_id_seq;
DROP TABLE public.feedback_items;
DROP SEQUENCE public.employments_id_seq;
DROP TABLE public.employments;
DROP SEQUENCE public.duplication_formulas_id_seq;
DROP TABLE public.duplication_formulas;
DROP SEQUENCE public.duplication_formula_details_id_seq;
DROP TABLE public.duplication_formula_details;
DROP SEQUENCE public.dashboard_preferences_id_seq;
DROP TABLE public.dashboard_preferences;
DROP SEQUENCE public.countries_id_seq;
DROP TABLE public.countries;
DROP SEQUENCE public.contacts_id_seq;
DROP TABLE public.contacts;
DROP SEQUENCE public.compile_lists_id_seq;
DROP TABLE public.compile_lists;
DROP SEQUENCE public.client_setups_id_seq;
DROP TABLE public.client_setups;
DROP SEQUENCE public.client_bank_accounts_id_seq;
DROP SEQUENCE public.campaigns_id_seq;
DROP TABLE public.campaigns;
DROP SEQUENCE public.bulk_emails_id_seq;
DROP TABLE public.bulk_emails;
DROP SEQUENCE public.bdrb_job_queues_id_seq;
DROP TABLE public.bdrb_job_queues;
DROP SEQUENCE public.banks_id_seq;
DROP TABLE public.banks;
DROP SEQUENCE public.bank_grids_id_seq;
DROP TABLE public.bank_grids;
DROP TABLE public.bank_accounts;
DROP SEQUENCE public.available_modules_id_seq;
DROP TABLE public.available_modules;
DROP SEQUENCE public.amazon_settings_id_seq;
DROP TABLE public.amazon_settings;
DROP SEQUENCE public.allocation_types_id_seq;
DROP TABLE public.allocation_types;
DROP SEQUENCE public.addresses_id_seq;
DROP TABLE public.addresses;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: addresses; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE addresses (
    id integer NOT NULL,
    building_name character varying(255),
    suite_unit character varying(255),
    street_number character varying(255),
    street_name character varying(255),
    town character varying(255),
    state character varying(255),
    district character varying(255),
    region character varying(255),
    country_id integer,
    postal_code character varying(255),
    time_zone character varying(255),
    map_reference character varying(255),
    bar_code character varying(255),
    address_type_id integer,
    addressable_id integer,
    addressable_type character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    priority_number integer
);


ALTER TABLE public.addresses OWNER TO rails;

--
-- Name: addresses_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE addresses_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.addresses_id_seq OWNER TO rails;

--
-- Name: addresses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE addresses_id_seq OWNED BY addresses.id;


--
-- Name: addresses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('addresses_id_seq', 118, true);


--
-- Name: allocation_types; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE allocation_types (
    id integer NOT NULL,
    name text,
    description text,
    link_module_id integer,
    post_to_history boolean,
    post_to_campaign boolean,
    send_receipt boolean,
    status boolean,
    remarks text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    link_module_name text
);


ALTER TABLE public.allocation_types OWNER TO rails;

--
-- Name: allocation_types_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE allocation_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.allocation_types_id_seq OWNER TO rails;

--
-- Name: allocation_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE allocation_types_id_seq OWNED BY allocation_types.id;


--
-- Name: allocation_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('allocation_types_id_seq', 1, false);


--
-- Name: amazon_settings; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE amazon_settings (
    id integer NOT NULL,
    name character varying(255),
    "position" integer,
    type character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    description character varying(255),
    status boolean,
    to_be_removed boolean
);


ALTER TABLE public.amazon_settings OWNER TO rails;

--
-- Name: amazon_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE amazon_settings_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.amazon_settings_id_seq OWNER TO rails;

--
-- Name: amazon_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE amazon_settings_id_seq OWNED BY amazon_settings.id;


--
-- Name: amazon_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('amazon_settings_id_seq', 110, true);


--
-- Name: available_modules; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE available_modules (
    id integer NOT NULL,
    name character varying(255),
    description character varying(255),
    status boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.available_modules OWNER TO rails;

--
-- Name: available_modules_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE available_modules_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.available_modules_id_seq OWNER TO rails;

--
-- Name: available_modules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE available_modules_id_seq OWNED BY available_modules.id;


--
-- Name: available_modules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('available_modules_id_seq', 1, false);


--
-- Name: bank_accounts; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE bank_accounts (
    id integer NOT NULL,
    bank_id integer,
    account_number text,
    account_purpose_id integer,
    status boolean,
    remarks text,
    entity_id integer,
    type text,
    account_type_id integer,
    priority_number integer
);


ALTER TABLE public.bank_accounts OWNER TO rails;

--
-- Name: bank_grids; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE bank_grids (
    id integer NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.bank_grids OWNER TO rails;

--
-- Name: bank_grids_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE bank_grids_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.bank_grids_id_seq OWNER TO rails;

--
-- Name: bank_grids_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE bank_grids_id_seq OWNED BY bank_grids.id;


--
-- Name: bank_grids_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('bank_grids_id_seq', 1, false);


--
-- Name: banks; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE banks (
    id integer NOT NULL,
    full_name text,
    short_name text,
    branch_name text,
    branch_number text,
    address_line_1 text,
    address_line_2 text,
    address_line_3 text,
    state text,
    postcode text,
    country_id integer,
    website text,
    general_email text,
    contact_person text,
    contact_person_job_title text,
    contact_person_email text,
    contact_phone text,
    contact_fax text,
    contact_mobile text,
    status boolean,
    status_reason text,
    remarks text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.banks OWNER TO rails;

--
-- Name: banks_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE banks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.banks_id_seq OWNER TO rails;

--
-- Name: banks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE banks_id_seq OWNED BY banks.id;


--
-- Name: banks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('banks_id_seq', 1, false);


--
-- Name: bdrb_job_queues; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE bdrb_job_queues (
    id integer NOT NULL,
    args text,
    worker_name character varying(255),
    worker_method character varying(255),
    job_key character varying(255),
    taken integer,
    finished integer,
    timeout integer,
    priority integer,
    submitted_at timestamp without time zone,
    started_at timestamp without time zone,
    finished_at timestamp without time zone,
    archived_at timestamp without time zone,
    tag character varying(255),
    submitter_info character varying(255),
    runner_info character varying(255),
    worker_key character varying(255),
    scheduled_at timestamp without time zone
);


ALTER TABLE public.bdrb_job_queues OWNER TO rails;

--
-- Name: bdrb_job_queues_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE bdrb_job_queues_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.bdrb_job_queues_id_seq OWNER TO rails;

--
-- Name: bdrb_job_queues_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE bdrb_job_queues_id_seq OWNED BY bdrb_job_queues.id;


--
-- Name: bdrb_job_queues_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('bdrb_job_queues_id_seq', 1, false);


--
-- Name: bulk_emails; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE bulk_emails (
    id integer NOT NULL,
    subject text,
    "from" text,
    "to" text,
    body text,
    dispatch_date timestamp without time zone,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    to_be_removed boolean DEFAULT false,
    status boolean DEFAULT true
);


ALTER TABLE public.bulk_emails OWNER TO rails;

--
-- Name: bulk_emails_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE bulk_emails_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.bulk_emails_id_seq OWNER TO rails;

--
-- Name: bulk_emails_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE bulk_emails_id_seq OWNED BY bulk_emails.id;


--
-- Name: bulk_emails_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('bulk_emails_id_seq', 1, false);


--
-- Name: campaigns; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE campaigns (
    id integer NOT NULL,
    name text,
    description text,
    target_amount text,
    start_date date,
    end_date date,
    status boolean,
    remarks text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.campaigns OWNER TO rails;

--
-- Name: campaigns_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE campaigns_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.campaigns_id_seq OWNER TO rails;

--
-- Name: campaigns_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE campaigns_id_seq OWNED BY campaigns.id;


--
-- Name: campaigns_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('campaigns_id_seq', 1, false);


--
-- Name: client_bank_accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE client_bank_accounts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.client_bank_accounts_id_seq OWNER TO rails;

--
-- Name: client_bank_accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE client_bank_accounts_id_seq OWNED BY bank_accounts.id;


--
-- Name: client_bank_accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('client_bank_accounts_id_seq', 1, false);


--
-- Name: client_setups; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE client_setups (
    id integer NOT NULL,
    organisation_id integer,
    client_id character varying(255),
    client_rego character varying(255),
    installation_date date,
    halt_date date,
    system_status boolean,
    modules_installed character varying(255),
    system_type character varying(255),
    system_purchase character varying(255),
    maximum_core_records integer,
    hosting_status character varying(255),
    number_of_users integer,
    number_of_login_attempts integer,
    new_account_graceperiod integer,
    session_timeout integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    password_lifetime integer,
    first_name character varying(255),
    last_name character varying(255),
    date_of_birth date,
    primary_phone_number character varying(255),
    secondary_phone_number character varying(255),
    primary_email_address character varying(255),
    secondary_email_address character varying(255),
    login_name character varying(255),
    account_id character varying(255),
    pin character varying(255),
    last_login timestamp without time zone,
    last_logoff timestamp without time zone,
    last_ip_address text,
    member_zone_power_password_hash text,
    member_zone_power_password_salt text,
    super_admin_power_password_hash text,
    super_admin_power_password_salt text,
    superadmin_message character varying(255),
    feedback_to character varying(255),
    reply_from character varying(255),
    home_country_id integer,
    level_0_label text,
    level_0_remarks text,
    level_1_label text,
    level_1_remarks text,
    level_2_label text,
    level_2_remarks text,
    level_3_label text,
    level_3_remarks text,
    level_4_label text,
    level_4_remarks text,
    level_5_label text,
    level_5_remarks text,
    level_6_label text,
    level_6_remarks text,
    level_7_label text,
    level_7_remarks text,
    level_8_label text,
    level_8_remarks text,
    level_9_label text,
    level_9_remarks text
);


ALTER TABLE public.client_setups OWNER TO rails;

--
-- Name: client_setups_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE client_setups_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.client_setups_id_seq OWNER TO rails;

--
-- Name: client_setups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE client_setups_id_seq OWNED BY client_setups.id;


--
-- Name: client_setups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('client_setups_id_seq', 1, true);


--
-- Name: compile_lists; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE compile_lists (
    id integer NOT NULL,
    login_account_id integer,
    list_header_id integer,
    type character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.compile_lists OWNER TO rails;

--
-- Name: compile_lists_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE compile_lists_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.compile_lists_id_seq OWNER TO rails;

--
-- Name: compile_lists_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE compile_lists_id_seq OWNED BY compile_lists.id;


--
-- Name: compile_lists_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('compile_lists_id_seq', 1, false);


--
-- Name: contacts; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE contacts (
    id integer NOT NULL,
    pre_value character varying(255),
    value character varying(255),
    post_value character varying(255),
    preferred_time character varying(255),
    preferred_day character varying(255),
    remarks character varying(255),
    type character varying(255),
    contactable_id integer,
    contactable_type character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    monday_hours character varying(255),
    tuesday_hours character varying(255),
    wednesday_hours character varying(255),
    thursday_hours character varying(255),
    friday_hours character varying(255),
    saturday_hours character varying(255),
    sunday_hours character varying(255),
    priority_number integer,
    contact_meta_type_id integer
);


ALTER TABLE public.contacts OWNER TO rails;

--
-- Name: contacts_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE contacts_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.contacts_id_seq OWNER TO rails;

--
-- Name: contacts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE contacts_id_seq OWNED BY contacts.id;


--
-- Name: contacts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('contacts_id_seq', 210, true);


--
-- Name: countries; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE countries (
    id integer NOT NULL,
    long_name character varying(255),
    short_name character varying(255),
    citizenship character varying(255),
    capital character varying(255),
    iso_code character varying(255),
    currency character varying(255),
    currency_subunit character varying(255),
    main_language_id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    dialup_code character varying(255)
);


ALTER TABLE public.countries OWNER TO rails;

--
-- Name: countries_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE countries_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.countries_id_seq OWNER TO rails;

--
-- Name: countries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE countries_id_seq OWNED BY countries.id;


--
-- Name: countries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('countries_id_seq', 4, true);


--
-- Name: dashboard_preferences; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE dashboard_preferences (
    id integer NOT NULL,
    login_account_id integer,
    column_id integer,
    box_id integer
);


ALTER TABLE public.dashboard_preferences OWNER TO rails;

--
-- Name: dashboard_preferences_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE dashboard_preferences_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.dashboard_preferences_id_seq OWNER TO rails;

--
-- Name: dashboard_preferences_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE dashboard_preferences_id_seq OWNED BY dashboard_preferences.id;


--
-- Name: dashboard_preferences_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('dashboard_preferences_id_seq', 1, false);


--
-- Name: duplication_formula_details; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE duplication_formula_details (
    id integer NOT NULL,
    duplication_formula_id integer,
    table_name character varying(255),
    field_name character varying(255),
    number_of_charecter integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    is_foreign_key boolean
);


ALTER TABLE public.duplication_formula_details OWNER TO rails;

--
-- Name: duplication_formula_details_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE duplication_formula_details_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.duplication_formula_details_id_seq OWNER TO rails;

--
-- Name: duplication_formula_details_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE duplication_formula_details_id_seq OWNED BY duplication_formula_details.id;


--
-- Name: duplication_formula_details_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('duplication_formula_details_id_seq', 24, true);


--
-- Name: duplication_formulas; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE duplication_formulas (
    id integer NOT NULL,
    description character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    duplication_space boolean,
    type character varying(255),
    "group" character varying(255),
    status boolean
);


ALTER TABLE public.duplication_formulas OWNER TO rails;

--
-- Name: duplication_formulas_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE duplication_formulas_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.duplication_formulas_id_seq OWNER TO rails;

--
-- Name: duplication_formulas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE duplication_formulas_id_seq OWNED BY duplication_formulas.id;


--
-- Name: duplication_formulas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('duplication_formulas_id_seq', 8, true);


--
-- Name: employments; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE employments (
    id integer NOT NULL,
    person_id integer,
    organisation_id integer,
    sequence_no integer,
    staff_reference character varying(255),
    position_reference character varying(255),
    position_name character varying(255),
    commenced_date date,
    term_length double precision,
    term_end_date date,
    duties_resposibilities character varying(255),
    hired_by integer,
    report_to integer,
    weekly_nominal_hours double precision,
    hourly_rate double precision,
    annual_base_salary double precision,
    plus_package character varying(255),
    award_other character varying(255),
    suspension_start_date date,
    suspension_end_date date,
    suspended_by integer,
    suspension_reason character varying(255),
    suspension_remarks character varying(255),
    termination_notice_date date,
    termination_date date,
    terminated_by integer,
    termination_reason character varying(255),
    termination_remarks character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    status boolean,
    department_id integer,
    section_id integer,
    cost_centre_id integer,
    position_title_id integer,
    position_classification_id integer,
    position_type_id integer,
    award_agreement_id integer,
    position_status_id integer,
    payment_frequency_id integer,
    payment_method_id integer,
    payment_day_id integer,
    suspension_type_id integer,
    termination_method_id integer
);


ALTER TABLE public.employments OWNER TO rails;

--
-- Name: employments_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE employments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.employments_id_seq OWNER TO rails;

--
-- Name: employments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE employments_id_seq OWNED BY employments.id;


--
-- Name: employments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('employments_id_seq', 1, false);


--
-- Name: feedback_items; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE feedback_items (
    id integer NOT NULL,
    login_account_id integer,
    subject text,
    content text,
    ip_address text,
    status text,
    feedback_date timestamp without time zone,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    response text,
    response_date timestamp without time zone,
    responded_to_by_id integer
);


ALTER TABLE public.feedback_items OWNER TO rails;

--
-- Name: feedback_items_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE feedback_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.feedback_items_id_seq OWNER TO rails;

--
-- Name: feedback_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE feedback_items_id_seq OWNED BY feedback_items.id;


--
-- Name: feedback_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('feedback_items_id_seq', 1, false);


--
-- Name: grids; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE grids (
    id integer NOT NULL,
    login_account_id integer,
    grid_object_id integer,
    type character varying(255),
    field_1 text,
    field_2 text,
    field_3 text,
    field_4 text,
    field_5 text,
    field_6 text,
    field_7 text,
    field_8 text,
    field_9 text,
    field_10 text
);


ALTER TABLE public.grids OWNER TO rails;

--
-- Name: grids_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE grids_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.grids_id_seq OWNER TO rails;

--
-- Name: grids_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE grids_id_seq OWNED BY grids.id;


--
-- Name: grids_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('grids_id_seq', 1653, true);


--
-- Name: group_lists; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE group_lists (
    id integer NOT NULL,
    tag_id integer,
    list_header_id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.group_lists OWNER TO rails;

--
-- Name: group_lists_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE group_lists_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.group_lists_id_seq OWNER TO rails;

--
-- Name: group_lists_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE group_lists_id_seq OWNED BY group_lists.id;


--
-- Name: group_lists_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('group_lists_id_seq', 3, true);


--
-- Name: group_permissions; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE group_permissions (
    id integer NOT NULL,
    system_permission_type_id integer,
    user_group_id integer
);


ALTER TABLE public.group_permissions OWNER TO rails;

--
-- Name: group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE group_permissions_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.group_permissions_id_seq OWNER TO rails;

--
-- Name: group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE group_permissions_id_seq OWNED BY group_permissions.id;


--
-- Name: group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('group_permissions_id_seq', 24, true);


--
-- Name: groups; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE groups (
    id integer NOT NULL,
    tags_id integer,
    name character varying(255),
    description character varying(255),
    status boolean,
    group_owner integer,
    start_date date,
    end_date date,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.groups OWNER TO rails;

--
-- Name: groups_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.groups_id_seq OWNER TO rails;

--
-- Name: groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE groups_id_seq OWNED BY groups.id;


--
-- Name: groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('groups_id_seq', 1, false);


--
-- Name: images; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE images (
    id integer NOT NULL,
    image_file_data bytea,
    image_filename character varying(255),
    image_width integer,
    image_height integer,
    imageable_id integer,
    imageable_type character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.images OWNER TO rails;

--
-- Name: images_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE images_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.images_id_seq OWNER TO rails;

--
-- Name: images_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE images_id_seq OWNED BY images.id;


--
-- Name: images_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('images_id_seq', 1, false);


--
-- Name: keyword_links; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE keyword_links (
    id integer NOT NULL,
    keyword_id integer,
    taggable_id integer,
    taggable_type character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.keyword_links OWNER TO rails;

--
-- Name: keyword_links_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE keyword_links_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.keyword_links_id_seq OWNER TO rails;

--
-- Name: keyword_links_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE keyword_links_id_seq OWNED BY keyword_links.id;


--
-- Name: keyword_links_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('keyword_links_id_seq', 1, false);


--
-- Name: keywords; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE keywords (
    id integer NOT NULL,
    name character varying(255),
    keyword_type_id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    status boolean,
    description character varying(255),
    to_be_removed boolean
);


ALTER TABLE public.keywords OWNER TO rails;

--
-- Name: keywords_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE keywords_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.keywords_id_seq OWNER TO rails;

--
-- Name: keywords_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE keywords_id_seq OWNED BY keywords.id;


--
-- Name: keywords_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('keywords_id_seq', 1, false);


--
-- Name: languages; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE languages (
    id integer NOT NULL,
    name character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.languages OWNER TO rails;

--
-- Name: languages_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE languages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.languages_id_seq OWNER TO rails;

--
-- Name: languages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE languages_id_seq OWNED BY languages.id;


--
-- Name: languages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('languages_id_seq', 1, false);


--
-- Name: list_details; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE list_details (
    id integer NOT NULL,
    list_header_id integer,
    person_id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.list_details OWNER TO rails;

--
-- Name: list_details_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE list_details_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.list_details_id_seq OWNER TO rails;

--
-- Name: list_details_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE list_details_id_seq OWNED BY list_details.id;


--
-- Name: list_details_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('list_details_id_seq', 126, true);


--
-- Name: list_headers; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE list_headers (
    id integer NOT NULL,
    type character varying(255),
    name character varying(255),
    description character varying(255),
    list_size integer,
    last_date_generated date,
    status boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    source character varying(255),
    source_type character varying(255),
    allow_duplication boolean,
    top_type character varying(255),
    top_value integer,
    login_account_id integer
);


ALTER TABLE public.list_headers OWNER TO rails;

--
-- Name: list_headers_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE list_headers_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.list_headers_id_seq OWNER TO rails;

--
-- Name: list_headers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE list_headers_id_seq OWNED BY list_headers.id;


--
-- Name: list_headers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('list_headers_id_seq', 6, true);


--
-- Name: login_accounts; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE login_accounts (
    id integer NOT NULL,
    person_id integer,
    user_name text,
    password_hash text,
    password_salt text,
    security_email text,
    password_hint text,
    question1_answer text,
    question2_answer text,
    question3_answer text,
    password_last_hash text,
    password_last_salt text,
    password_last_date date,
    last_login timestamp without time zone,
    last_logoff timestamp without time zone,
    last_ip_address text,
    session_timeout integer,
    authentication_token text,
    authentication_grace_period integer,
    login_status boolean,
    system_user boolean,
    security_question1_id integer,
    security_question2_id integer,
    security_question3_id integer,
    access_attempt_ip text,
    access_attempts_count integer,
    password_by_admin boolean,
    password_lifetime integer,
    type character varying(255),
    password_updated_at timestamp without time zone,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    online_status boolean
);


ALTER TABLE public.login_accounts OWNER TO rails;

--
-- Name: login_accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE login_accounts_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.login_accounts_id_seq OWNER TO rails;

--
-- Name: login_accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE login_accounts_id_seq OWNED BY login_accounts.id;


--
-- Name: login_accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('login_accounts_id_seq', 11, true);


--
-- Name: master_docs; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE master_docs (
    id integer NOT NULL,
    doc_number character varying(255),
    doc_reference character varying(255),
    security_number character varying(255),
    category character varying(255),
    long_name character varying(255),
    short_name character varying(255),
    name_on_doc character varying(255),
    other_on_doc character varying(255),
    issue_person character varying(255),
    issue_organisation character varying(255),
    issue_place character varying(255),
    issue_state character varying(255),
    action_taken character varying(255),
    remarks character varying(255),
    issue_date date,
    expiry_date date,
    reminder boolean,
    master_doc_type_id integer,
    entity_id integer,
    entity_type character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    priority_number integer,
    issue_country_id integer
);


ALTER TABLE public.master_docs OWNER TO rails;

--
-- Name: master_docs_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE master_docs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.master_docs_id_seq OWNER TO rails;

--
-- Name: master_docs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE master_docs_id_seq OWNED BY master_docs.id;


--
-- Name: master_docs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('master_docs_id_seq', 1, false);


--
-- Name: message_templates; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE message_templates (
    id integer NOT NULL,
    name text,
    body text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.message_templates OWNER TO rails;

--
-- Name: message_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE message_templates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.message_templates_id_seq OWNER TO rails;

--
-- Name: message_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE message_templates_id_seq OWNED BY message_templates.id;


--
-- Name: message_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('message_templates_id_seq', 1, false);


--
-- Name: notes; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE notes (
    id integer NOT NULL,
    label character varying(255),
    short_description character varying(255),
    alarm_date date,
    alarm_time time without time zone,
    active boolean,
    body_text character varying(255),
    noteable_id integer,
    noteable_type character varying(255),
    note_type_id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.notes OWNER TO rails;

--
-- Name: notes_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE notes_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.notes_id_seq OWNER TO rails;

--
-- Name: notes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE notes_id_seq OWNED BY notes.id;


--
-- Name: notes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('notes_id_seq', 1, true);


--
-- Name: organisation_groups; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE organisation_groups (
    id integer NOT NULL,
    organisation_id integer,
    tag_id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.organisation_groups OWNER TO rails;

--
-- Name: organisation_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE organisation_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.organisation_groups_id_seq OWNER TO rails;

--
-- Name: organisation_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE organisation_groups_id_seq OWNED BY organisation_groups.id;


--
-- Name: organisation_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('organisation_groups_id_seq', 1, false);


--
-- Name: organisation_hierarchies; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE organisation_hierarchies (
    id integer NOT NULL,
    hierarchy_level integer,
    hierarchy_name text,
    remarks text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.organisation_hierarchies OWNER TO rails;

--
-- Name: organisation_hierarchies_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE organisation_hierarchies_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.organisation_hierarchies_id_seq OWNER TO rails;

--
-- Name: organisation_hierarchies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE organisation_hierarchies_id_seq OWNED BY organisation_hierarchies.id;


--
-- Name: organisation_hierarchies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('organisation_hierarchies_id_seq', 1, false);


--
-- Name: organisation_key_personnels; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE organisation_key_personnels (
    id integer NOT NULL,
    organisation_id integer,
    person_id integer,
    designation text,
    remarks text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.organisation_key_personnels OWNER TO rails;

--
-- Name: organisation_key_personnels_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE organisation_key_personnels_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.organisation_key_personnels_id_seq OWNER TO rails;

--
-- Name: organisation_key_personnels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE organisation_key_personnels_id_seq OWNED BY organisation_key_personnels.id;


--
-- Name: organisation_key_personnels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('organisation_key_personnels_id_seq', 1, false);


--
-- Name: organisation_relationships; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE organisation_relationships (
    id integer NOT NULL,
    source_organisation_id integer,
    related_organisation_id integer,
    remarks character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.organisation_relationships OWNER TO rails;

--
-- Name: organisation_relationships_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE organisation_relationships_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.organisation_relationships_id_seq OWNER TO rails;

--
-- Name: organisation_relationships_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE organisation_relationships_id_seq OWNED BY organisation_relationships.id;


--
-- Name: organisation_relationships_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('organisation_relationships_id_seq', 1, false);


--
-- Name: organisation_subsidiaries; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE organisation_subsidiaries (
    id integer NOT NULL,
    parent_id integer,
    organisation_id integer,
    remarks text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.organisation_subsidiaries OWNER TO rails;

--
-- Name: organisation_subsidiaries_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE organisation_subsidiaries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.organisation_subsidiaries_id_seq OWNER TO rails;

--
-- Name: organisation_subsidiaries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE organisation_subsidiaries_id_seq OWNED BY organisation_subsidiaries.id;


--
-- Name: organisation_subsidiaries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('organisation_subsidiaries_id_seq', 1, false);


--
-- Name: organisations; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE organisations (
    id integer NOT NULL,
    custom_id text,
    full_name text,
    short_name text,
    trading_as text,
    registered_name text,
    registered_number text,
    registered_date date,
    registered_country_id integer,
    tax_file_no text,
    legal_no_1 text,
    legal_no_2 text,
    industrial_code text,
    number_of_full_time_employees integer,
    number_of_part_time_employees integer,
    number_of_contractors integer,
    number_of_volunteers integer,
    number_of_other_workers integer,
    business_mission text,
    organisation_hierarchy_id integer,
    remarks character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    organisation_type_id integer,
    business_type_id integer,
    industry_sector_id integer,
    business_category_id integer,
    onrecord_since date,
    business_sub_category character varying(255),
    duplication_value character varying(255),
    type character varying(255),
    created_by_id integer,
    updated_by_id integer,
    level integer,
    level_label character varying(255)
);


ALTER TABLE public.organisations OWNER TO rails;

--
-- Name: organisations_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE organisations_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.organisations_id_seq OWNER TO rails;

--
-- Name: organisations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE organisations_id_seq OWNED BY organisations.id;


--
-- Name: organisations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('organisations_id_seq', 1, true);


--
-- Name: people; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE people (
    id integer NOT NULL,
    custom_id character varying(255),
    primary_title_id integer,
    second_title_id integer,
    first_name character varying(255),
    middle_name character varying(255),
    family_name character varying(255),
    maiden_name character varying(255),
    preferred_name character varying(255),
    initials character varying(255),
    post_title character varying(255),
    birth_date date,
    primary_salutation character varying(255),
    second_salutation character varying(255),
    industry_sector_id integer,
    interests character varying(255),
    origin_country_id integer,
    residence_country_id integer,
    nationality_id integer,
    other_nationality_id integer,
    language_id integer,
    other_language_id integer,
    religion_id integer,
    onrecord_since date,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    marital_status_id integer,
    gender_id integer,
    duplication_value character varying(255)
);


ALTER TABLE public.people OWNER TO rails;

--
-- Name: people_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE people_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.people_id_seq OWNER TO rails;

--
-- Name: people_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE people_id_seq OWNED BY people.id;


--
-- Name: people_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('people_id_seq', 120, true);


--
-- Name: person_bank_accounts; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE person_bank_accounts (
    id integer NOT NULL,
    person_id integer,
    bank_id integer,
    account_number text,
    account_type_id integer,
    status boolean,
    remarks text
);


ALTER TABLE public.person_bank_accounts OWNER TO rails;

--
-- Name: person_bank_accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE person_bank_accounts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.person_bank_accounts_id_seq OWNER TO rails;

--
-- Name: person_bank_accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE person_bank_accounts_id_seq OWNED BY person_bank_accounts.id;


--
-- Name: person_bank_accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('person_bank_accounts_id_seq', 1, false);


--
-- Name: person_groups; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE person_groups (
    id integer NOT NULL,
    people_id integer,
    tag_id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.person_groups OWNER TO rails;

--
-- Name: person_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE person_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.person_groups_id_seq OWNER TO rails;

--
-- Name: person_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE person_groups_id_seq OWNED BY person_groups.id;


--
-- Name: person_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('person_groups_id_seq', 1, false);


--
-- Name: person_roles; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE person_roles (
    id integer NOT NULL,
    person_id integer,
    role_id integer,
    remarks character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    sequence_no integer,
    assigned_by integer,
    approved_by integer,
    assignment_date date,
    start_date date,
    end_date date,
    supervised_by integer,
    managed_by integer
);


ALTER TABLE public.person_roles OWNER TO rails;

--
-- Name: person_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE person_roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.person_roles_id_seq OWNER TO rails;

--
-- Name: person_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE person_roles_id_seq OWNED BY person_roles.id;


--
-- Name: person_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('person_roles_id_seq', 1, false);


--
-- Name: post_areas; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE post_areas (
    id integer NOT NULL,
    country_id integer,
    division_name character varying(255),
    remarks character varying(255),
    type character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.post_areas OWNER TO rails;

--
-- Name: post_areas_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE post_areas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.post_areas_id_seq OWNER TO rails;

--
-- Name: post_areas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE post_areas_id_seq OWNED BY post_areas.id;


--
-- Name: post_areas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('post_areas_id_seq', 1, false);


--
-- Name: postcodes; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE postcodes (
    id integer NOT NULL,
    country_id integer,
    governance text,
    province text,
    state text,
    region text,
    district text,
    zone text,
    city text,
    town text,
    suburb text,
    postcode text,
    mail_code text,
    bulk_code text,
    geographical_area_id integer,
    electoral_area_id integer
);


ALTER TABLE public.postcodes OWNER TO rails;

--
-- Name: postcodes_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE postcodes_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.postcodes_id_seq OWNER TO rails;

--
-- Name: postcodes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE postcodes_id_seq OWNED BY postcodes.id;


--
-- Name: postcodes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('postcodes_id_seq', 13098, true);


--
-- Name: potential_members; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE potential_members (
    id integer NOT NULL,
    first_name character varying(255),
    family_name character varying(255),
    email character varying(255)
);


ALTER TABLE public.potential_members OWNER TO rails;

--
-- Name: potential_members_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE potential_members_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.potential_members_id_seq OWNER TO rails;

--
-- Name: potential_members_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE potential_members_id_seq OWNED BY potential_members.id;


--
-- Name: potential_members_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('potential_members_id_seq', 2, true);


--
-- Name: query_criterias; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE query_criterias (
    id integer NOT NULL,
    query_header_id integer,
    sequence integer,
    table_name character varying(255),
    field_name character varying(255),
    data_type character varying(255),
    operator character varying(255),
    option character varying(255),
    value character varying(255),
    status boolean
);


ALTER TABLE public.query_criterias OWNER TO rails;

--
-- Name: query_criterias_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE query_criterias_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.query_criterias_id_seq OWNER TO rails;

--
-- Name: query_criterias_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE query_criterias_id_seq OWNED BY query_criterias.id;


--
-- Name: query_criterias_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('query_criterias_id_seq', 1, false);


--
-- Name: query_details; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE query_details (
    id integer NOT NULL,
    query_header_id integer,
    sequence integer,
    table_name character varying(255),
    field_name character varying(255),
    status boolean,
    type character varying(255),
    ascending boolean,
    data_type character varying(255)
);


ALTER TABLE public.query_details OWNER TO rails;

--
-- Name: query_details_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE query_details_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.query_details_id_seq OWNER TO rails;

--
-- Name: query_details_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE query_details_id_seq OWNED BY query_details.id;


--
-- Name: query_details_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('query_details_id_seq', 1, false);


--
-- Name: query_headers; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE query_headers (
    id integer NOT NULL,
    name character varying(255),
    description character varying(255),
    last_date_executed date,
    result_size integer,
    status boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    "group" character varying(255),
    created_by_id integer,
    updated_by_id integer,
    top_value integer,
    top_type character varying(255),
    allow_duplication boolean
);


ALTER TABLE public.query_headers OWNER TO rails;

--
-- Name: query_headers_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE query_headers_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.query_headers_id_seq OWNER TO rails;

--
-- Name: query_headers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE query_headers_id_seq OWNED BY query_headers.id;


--
-- Name: query_headers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('query_headers_id_seq', 10, true);


--
-- Name: receipt_accounts; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE receipt_accounts (
    id integer NOT NULL,
    name text,
    description text,
    post_to_history boolean,
    post_to_campaign boolean,
    send_receipt boolean,
    status boolean,
    remarks text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    link_module_id integer,
    link_module_name text
);


ALTER TABLE public.receipt_accounts OWNER TO rails;

--
-- Name: receipt_accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE receipt_accounts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.receipt_accounts_id_seq OWNER TO rails;

--
-- Name: receipt_accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE receipt_accounts_id_seq OWNED BY receipt_accounts.id;


--
-- Name: receipt_accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('receipt_accounts_id_seq', 1, false);


--
-- Name: receipt_methods; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE receipt_methods (
    id integer NOT NULL,
    name text,
    description text,
    receipt_method_type_id integer,
    status boolean,
    remarks text,
    card_merchant_number text,
    card_name text,
    card_location text,
    card_cost text,
    card_floor_limit text,
    card_lines_per_page integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.receipt_methods OWNER TO rails;

--
-- Name: receipt_methods_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE receipt_methods_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.receipt_methods_id_seq OWNER TO rails;

--
-- Name: receipt_methods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE receipt_methods_id_seq OWNED BY receipt_methods.id;


--
-- Name: receipt_methods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('receipt_methods_id_seq', 1, false);


--
-- Name: relationships; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE relationships (
    id integer NOT NULL,
    source_person_id integer,
    related_person_id integer,
    relationship_type_id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.relationships OWNER TO rails;

--
-- Name: relationships_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE relationships_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.relationships_id_seq OWNER TO rails;

--
-- Name: relationships_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE relationships_id_seq OWNED BY relationships.id;


--
-- Name: relationships_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('relationships_id_seq', 1, false);


--
-- Name: role_conditions; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE role_conditions (
    id integer NOT NULL,
    role_id integer,
    priority_number integer,
    doctype_id integer,
    remarks character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.role_conditions OWNER TO rails;

--
-- Name: role_conditions_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE role_conditions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.role_conditions_id_seq OWNER TO rails;

--
-- Name: role_conditions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE role_conditions_id_seq OWNED BY role_conditions.id;


--
-- Name: role_conditions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('role_conditions_id_seq', 1, false);


--
-- Name: roles; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE roles (
    id integer NOT NULL,
    name character varying(255),
    role_type_id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    description character varying(255),
    remarks character varying(255),
    role_status boolean,
    to_be_removed boolean
);


ALTER TABLE public.roles OWNER TO rails;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.roles_id_seq OWNER TO rails;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE roles_id_seq OWNED BY roles.id;


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('roles_id_seq', 1, false);


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE schema_migrations (
    version character varying(255) NOT NULL
);


ALTER TABLE public.schema_migrations OWNER TO rails;

--
-- Name: simple_captcha_data; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE simple_captcha_data (
    id integer NOT NULL,
    key character varying(40),
    value character varying(6),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.simple_captcha_data OWNER TO rails;

--
-- Name: simple_captcha_data_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE simple_captcha_data_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.simple_captcha_data_id_seq OWNER TO rails;

--
-- Name: simple_captcha_data_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE simple_captcha_data_id_seq OWNED BY simple_captcha_data.id;


--
-- Name: simple_captcha_data_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('simple_captcha_data_id_seq', 9, true);


--
-- Name: sources; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE sources (
    id integer NOT NULL,
    campaign_id integer,
    name text,
    description text,
    volume integer,
    cost text,
    dead_return integer,
    letter_id integer,
    account_code_id integer,
    status boolean,
    remarks text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.sources OWNER TO rails;

--
-- Name: sources_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE sources_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.sources_id_seq OWNER TO rails;

--
-- Name: sources_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE sources_id_seq OWNED BY sources.id;


--
-- Name: sources_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('sources_id_seq', 1, false);


--
-- Name: system_logs; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE system_logs (
    id integer NOT NULL,
    login_account_id integer,
    message text,
    controller text,
    action text,
    ip_address text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    status text
);


ALTER TABLE public.system_logs OWNER TO rails;

--
-- Name: system_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE system_logs_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.system_logs_id_seq OWNER TO rails;

--
-- Name: system_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE system_logs_id_seq OWNED BY system_logs.id;


--
-- Name: system_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('system_logs_id_seq', 660, true);


--
-- Name: system_news; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE system_news (
    id integer NOT NULL,
    description text,
    event_date timestamp without time zone,
    created_by_id integer,
    updated_by_id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    title character varying(255),
    status boolean
);


ALTER TABLE public.system_news OWNER TO rails;

--
-- Name: system_news_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE system_news_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.system_news_id_seq OWNER TO rails;

--
-- Name: system_news_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE system_news_id_seq OWNED BY system_news.id;


--
-- Name: system_news_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('system_news_id_seq', 1, false);


--
-- Name: tag_meta_types; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE tag_meta_types (
    id integer NOT NULL,
    name text,
    description text,
    "position" integer,
    status boolean,
    type text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    category character varying(255),
    to_be_removed boolean
);


ALTER TABLE public.tag_meta_types OWNER TO rails;

--
-- Name: tag_meta_types_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE tag_meta_types_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.tag_meta_types_id_seq OWNER TO rails;

--
-- Name: tag_meta_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE tag_meta_types_id_seq OWNED BY tag_meta_types.id;


--
-- Name: tag_meta_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('tag_meta_types_id_seq', 17, true);


--
-- Name: tag_types; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE tag_types (
    id integer NOT NULL,
    name text,
    tag_meta_type_id integer,
    description text,
    "position" integer,
    status boolean,
    type text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    category character varying(255),
    to_be_removed boolean
);


ALTER TABLE public.tag_types OWNER TO rails;

--
-- Name: tag_types_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE tag_types_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.tag_types_id_seq OWNER TO rails;

--
-- Name: tag_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE tag_types_id_seq OWNED BY tag_types.id;


--
-- Name: tag_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('tag_types_id_seq', 86, true);


--
-- Name: tags; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE tags (
    id integer NOT NULL,
    name text,
    tag_type_id integer,
    description text,
    "position" integer,
    status boolean,
    type text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    category character varying(255),
    to_be_removed boolean
);


ALTER TABLE public.tags OWNER TO rails;

--
-- Name: tags_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE tags_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.tags_id_seq OWNER TO rails;

--
-- Name: tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE tags_id_seq OWNED BY tags.id;


--
-- Name: tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('tags_id_seq', 16, true);


--
-- Name: to_do_lists; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE to_do_lists (
    id integer NOT NULL,
    description text,
    status character varying(255),
    due_date timestamp without time zone,
    created_by_id integer,
    updated_by_id integer,
    login_account_id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.to_do_lists OWNER TO rails;

--
-- Name: to_do_lists_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE to_do_lists_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.to_do_lists_id_seq OWNER TO rails;

--
-- Name: to_do_lists_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE to_do_lists_id_seq OWNED BY to_do_lists.id;


--
-- Name: to_do_lists_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('to_do_lists_id_seq', 1, false);


--
-- Name: transaction_allocations; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE transaction_allocations (
    id integer NOT NULL,
    transaction_header_id integer,
    receipt_account_id integer,
    campaign_id integer,
    source_id integer,
    amount numeric(11,3),
    letter_id integer,
    letter_sent boolean,
    date_sent date,
    extention_id integer,
    extention_type character varying(255),
    cluster_id integer,
    cluster_type character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.transaction_allocations OWNER TO rails;

--
-- Name: transaction_allocations_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE transaction_allocations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.transaction_allocations_id_seq OWNER TO rails;

--
-- Name: transaction_allocations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE transaction_allocations_id_seq OWNED BY transaction_allocations.id;


--
-- Name: transaction_allocations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('transaction_allocations_id_seq', 1, false);


--
-- Name: transaction_headers; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE transaction_headers (
    id integer NOT NULL,
    entity_id integer,
    entity_type character varying(255),
    todays_date date,
    transaction_date date,
    receipt_meta_type_id integer,
    receipt_meta_type_name character varying(255),
    receipt_type_id integer,
    receipt_type_name character varying(255),
    bank_account_id integer,
    bank_account_name character varying(255),
    bank_run_id integer,
    receipt_number integer,
    letter_id integer,
    letter_sent boolean,
    date_sent date,
    total_amount numeric(11,3),
    notes text,
    received_via_id integer,
    received_via_name character varying(255),
    banked boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.transaction_headers OWNER TO rails;

--
-- Name: transaction_headers_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE transaction_headers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.transaction_headers_id_seq OWNER TO rails;

--
-- Name: transaction_headers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE transaction_headers_id_seq OWNED BY transaction_headers.id;


--
-- Name: transaction_headers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('transaction_headers_id_seq', 1, false);


--
-- Name: transaction_type_details; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE transaction_type_details (
    id integer NOT NULL,
    transaction_header_id integer,
    type character varying(255),
    name_on_cheque character varying(255),
    cheque_number character varying(255),
    date_on_cheque character varying(255),
    name_on_card character varying(255),
    card_number character varying(255),
    expire_month character varying(255),
    expire_year character varying(255),
    cvv_number character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    bank_id integer
);


ALTER TABLE public.transaction_type_details OWNER TO rails;

--
-- Name: transaction_type_details_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE transaction_type_details_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.transaction_type_details_id_seq OWNER TO rails;

--
-- Name: transaction_type_details_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE transaction_type_details_id_seq OWNED BY transaction_type_details.id;


--
-- Name: transaction_type_details_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('transaction_type_details_id_seq', 1, false);


--
-- Name: user_groups; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE user_groups (
    id integer NOT NULL,
    user_id integer,
    group_id integer
);


ALTER TABLE public.user_groups OWNER TO rails;

--
-- Name: user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE user_groups_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.user_groups_id_seq OWNER TO rails;

--
-- Name: user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE user_groups_id_seq OWNED BY user_groups.id;


--
-- Name: user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('user_groups_id_seq', 11, true);


--
-- Name: user_lists; Type: TABLE; Schema: public; Owner: rails; Tablespace: 
--

CREATE TABLE user_lists (
    id integer NOT NULL,
    user_id integer,
    list_header_id integer
);


ALTER TABLE public.user_lists OWNER TO rails;

--
-- Name: user_lists_id_seq; Type: SEQUENCE; Schema: public; Owner: rails
--

CREATE SEQUENCE user_lists_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.user_lists_id_seq OWNER TO rails;

--
-- Name: user_lists_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rails
--

ALTER SEQUENCE user_lists_id_seq OWNED BY user_lists.id;


--
-- Name: user_lists_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rails
--

SELECT pg_catalog.setval('user_lists_id_seq', 1, true);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE addresses ALTER COLUMN id SET DEFAULT nextval('addresses_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE allocation_types ALTER COLUMN id SET DEFAULT nextval('allocation_types_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE amazon_settings ALTER COLUMN id SET DEFAULT nextval('amazon_settings_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE available_modules ALTER COLUMN id SET DEFAULT nextval('available_modules_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE bank_accounts ALTER COLUMN id SET DEFAULT nextval('client_bank_accounts_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE bank_grids ALTER COLUMN id SET DEFAULT nextval('bank_grids_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE banks ALTER COLUMN id SET DEFAULT nextval('banks_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE bdrb_job_queues ALTER COLUMN id SET DEFAULT nextval('bdrb_job_queues_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE bulk_emails ALTER COLUMN id SET DEFAULT nextval('bulk_emails_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE campaigns ALTER COLUMN id SET DEFAULT nextval('campaigns_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE client_setups ALTER COLUMN id SET DEFAULT nextval('client_setups_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE compile_lists ALTER COLUMN id SET DEFAULT nextval('compile_lists_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE contacts ALTER COLUMN id SET DEFAULT nextval('contacts_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE countries ALTER COLUMN id SET DEFAULT nextval('countries_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE dashboard_preferences ALTER COLUMN id SET DEFAULT nextval('dashboard_preferences_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE duplication_formula_details ALTER COLUMN id SET DEFAULT nextval('duplication_formula_details_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE duplication_formulas ALTER COLUMN id SET DEFAULT nextval('duplication_formulas_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE employments ALTER COLUMN id SET DEFAULT nextval('employments_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE feedback_items ALTER COLUMN id SET DEFAULT nextval('feedback_items_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE grids ALTER COLUMN id SET DEFAULT nextval('grids_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE group_lists ALTER COLUMN id SET DEFAULT nextval('group_lists_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE group_permissions ALTER COLUMN id SET DEFAULT nextval('group_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE groups ALTER COLUMN id SET DEFAULT nextval('groups_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE images ALTER COLUMN id SET DEFAULT nextval('images_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE keyword_links ALTER COLUMN id SET DEFAULT nextval('keyword_links_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE keywords ALTER COLUMN id SET DEFAULT nextval('keywords_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE languages ALTER COLUMN id SET DEFAULT nextval('languages_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE list_details ALTER COLUMN id SET DEFAULT nextval('list_details_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE list_headers ALTER COLUMN id SET DEFAULT nextval('list_headers_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE login_accounts ALTER COLUMN id SET DEFAULT nextval('login_accounts_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE master_docs ALTER COLUMN id SET DEFAULT nextval('master_docs_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE message_templates ALTER COLUMN id SET DEFAULT nextval('message_templates_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE notes ALTER COLUMN id SET DEFAULT nextval('notes_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE organisation_groups ALTER COLUMN id SET DEFAULT nextval('organisation_groups_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE organisation_hierarchies ALTER COLUMN id SET DEFAULT nextval('organisation_hierarchies_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE organisation_key_personnels ALTER COLUMN id SET DEFAULT nextval('organisation_key_personnels_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE organisation_relationships ALTER COLUMN id SET DEFAULT nextval('organisation_relationships_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE organisation_subsidiaries ALTER COLUMN id SET DEFAULT nextval('organisation_subsidiaries_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE organisations ALTER COLUMN id SET DEFAULT nextval('organisations_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE people ALTER COLUMN id SET DEFAULT nextval('people_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE person_bank_accounts ALTER COLUMN id SET DEFAULT nextval('person_bank_accounts_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE person_groups ALTER COLUMN id SET DEFAULT nextval('person_groups_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE person_roles ALTER COLUMN id SET DEFAULT nextval('person_roles_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE post_areas ALTER COLUMN id SET DEFAULT nextval('post_areas_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE postcodes ALTER COLUMN id SET DEFAULT nextval('postcodes_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE potential_members ALTER COLUMN id SET DEFAULT nextval('potential_members_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE query_criterias ALTER COLUMN id SET DEFAULT nextval('query_criterias_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE query_details ALTER COLUMN id SET DEFAULT nextval('query_details_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE query_headers ALTER COLUMN id SET DEFAULT nextval('query_headers_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE receipt_accounts ALTER COLUMN id SET DEFAULT nextval('receipt_accounts_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE receipt_methods ALTER COLUMN id SET DEFAULT nextval('receipt_methods_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE relationships ALTER COLUMN id SET DEFAULT nextval('relationships_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE role_conditions ALTER COLUMN id SET DEFAULT nextval('role_conditions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE roles ALTER COLUMN id SET DEFAULT nextval('roles_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE simple_captcha_data ALTER COLUMN id SET DEFAULT nextval('simple_captcha_data_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE sources ALTER COLUMN id SET DEFAULT nextval('sources_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE system_logs ALTER COLUMN id SET DEFAULT nextval('system_logs_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE system_news ALTER COLUMN id SET DEFAULT nextval('system_news_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE tag_meta_types ALTER COLUMN id SET DEFAULT nextval('tag_meta_types_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE tag_types ALTER COLUMN id SET DEFAULT nextval('tag_types_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE tags ALTER COLUMN id SET DEFAULT nextval('tags_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE to_do_lists ALTER COLUMN id SET DEFAULT nextval('to_do_lists_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE transaction_allocations ALTER COLUMN id SET DEFAULT nextval('transaction_allocations_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE transaction_headers ALTER COLUMN id SET DEFAULT nextval('transaction_headers_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE transaction_type_details ALTER COLUMN id SET DEFAULT nextval('transaction_type_details_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE user_groups ALTER COLUMN id SET DEFAULT nextval('user_groups_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rails
--

ALTER TABLE user_lists ALTER COLUMN id SET DEFAULT nextval('user_lists_id_seq'::regclass);


--
-- Data for Name: addresses; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY addresses (id, building_name, suite_unit, street_number, street_name, town, state, district, region, country_id, postal_code, time_zone, map_reference, bar_code, address_type_id, addressable_id, addressable_type, created_at, updated_at, priority_number) FROM stdin;
\.
copy addresses (id, building_name, suite_unit, street_number, street_name, town, state, district, region, country_id, postal_code, time_zone, map_reference, bar_code, address_type_id, addressable_id, addressable_type, created_at, updated_at, priority_number)  from '$$PATH$$/2320.dat' ;
--
-- Data for Name: allocation_types; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY allocation_types (id, name, description, link_module_id, post_to_history, post_to_campaign, send_receipt, status, remarks, created_at, updated_at, link_module_name) FROM stdin;
\.
copy allocation_types (id, name, description, link_module_id, post_to_history, post_to_campaign, send_receipt, status, remarks, created_at, updated_at, link_module_name)  from '$$PATH$$/2377.dat' ;
--
-- Data for Name: amazon_settings; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY amazon_settings (id, name, "position", type, created_at, updated_at, description, status, to_be_removed) FROM stdin;
\.
copy amazon_settings (id, name, "position", type, created_at, updated_at, description, status, to_be_removed)  from '$$PATH$$/2336.dat' ;
--
-- Data for Name: available_modules; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY available_modules (id, name, description, status, created_at, updated_at) FROM stdin;
\.
copy available_modules (id, name, description, status, created_at, updated_at)  from '$$PATH$$/2365.dat' ;
--
-- Data for Name: bank_accounts; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY bank_accounts (id, bank_id, account_number, account_purpose_id, status, remarks, entity_id, type, account_type_id, priority_number) FROM stdin;
\.
copy bank_accounts (id, bank_id, account_number, account_purpose_id, status, remarks, entity_id, type, account_type_id, priority_number)  from '$$PATH$$/2375.dat' ;
--
-- Data for Name: bank_grids; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY bank_grids (id, created_at, updated_at) FROM stdin;
\.
copy bank_grids (id, created_at, updated_at)  from '$$PATH$$/2378.dat' ;
--
-- Data for Name: banks; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY banks (id, full_name, short_name, branch_name, branch_number, address_line_1, address_line_2, address_line_3, state, postcode, country_id, website, general_email, contact_person, contact_person_job_title, contact_person_email, contact_phone, contact_fax, contact_mobile, status, status_reason, remarks, created_at, updated_at) FROM stdin;
\.
copy banks (id, full_name, short_name, branch_name, branch_number, address_line_1, address_line_2, address_line_3, state, postcode, country_id, website, general_email, contact_person, contact_person_job_title, contact_person_email, contact_phone, contact_fax, contact_mobile, status, status_reason, remarks, created_at, updated_at)  from '$$PATH$$/2370.dat' ;
--
-- Data for Name: bdrb_job_queues; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY bdrb_job_queues (id, args, worker_name, worker_method, job_key, taken, finished, timeout, priority, submitted_at, started_at, finished_at, archived_at, tag, submitter_info, runner_info, worker_key, scheduled_at) FROM stdin;
\.
copy bdrb_job_queues (id, args, worker_name, worker_method, job_key, taken, finished, timeout, priority, submitted_at, started_at, finished_at, archived_at, tag, submitter_info, runner_info, worker_key, scheduled_at)  from '$$PATH$$/2367.dat' ;
--
-- Data for Name: bulk_emails; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY bulk_emails (id, subject, "from", "to", body, dispatch_date, created_at, updated_at, to_be_removed, status) FROM stdin;
\.
copy bulk_emails (id, subject, "from", "to", body, dispatch_date, created_at, updated_at, to_be_removed, status)  from '$$PATH$$/2382.dat' ;
--
-- Data for Name: campaigns; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY campaigns (id, name, description, target_amount, start_date, end_date, status, remarks, created_at, updated_at) FROM stdin;
\.
copy campaigns (id, name, description, target_amount, start_date, end_date, status, remarks, created_at, updated_at)  from '$$PATH$$/2371.dat' ;
--
-- Data for Name: client_setups; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY client_setups (id, organisation_id, client_id, client_rego, installation_date, halt_date, system_status, modules_installed, system_type, system_purchase, maximum_core_records, hosting_status, number_of_users, number_of_login_attempts, new_account_graceperiod, session_timeout, created_at, updated_at, password_lifetime, first_name, last_name, date_of_birth, primary_phone_number, secondary_phone_number, primary_email_address, secondary_email_address, login_name, account_id, pin, last_login, last_logoff, last_ip_address, member_zone_power_password_hash, member_zone_power_password_salt, super_admin_power_password_hash, super_admin_power_password_salt, superadmin_message, feedback_to, reply_from, home_country_id, level_0_label, level_0_remarks, level_1_label, level_1_remarks, level_2_label, level_2_remarks, level_3_label, level_3_remarks, level_4_label, level_4_remarks, level_5_label, level_5_remarks, level_6_label, level_6_remarks, level_7_label, level_7_remarks, level_8_label, level_8_remarks, level_9_label, level_9_remarks) FROM stdin;
\.
copy client_setups (id, organisation_id, client_id, client_rego, installation_date, halt_date, system_status, modules_installed, system_type, system_purchase, maximum_core_records, hosting_status, number_of_users, number_of_login_attempts, new_account_graceperiod, session_timeout, created_at, updated_at, password_lifetime, first_name, last_name, date_of_birth, primary_phone_number, secondary_phone_number, primary_email_address, secondary_email_address, login_name, account_id, pin, last_login, last_logoff, last_ip_address, member_zone_power_password_hash, member_zone_power_password_salt, super_admin_power_password_hash, super_admin_power_password_salt, superadmin_message, feedback_to, reply_from, home_country_id, level_0_label, level_0_remarks, level_1_label, level_1_remarks, level_2_label, level_2_remarks, level_3_label, level_3_remarks, level_4_label, level_4_remarks, level_5_label, level_5_remarks, level_6_label, level_6_remarks, level_7_label, level_7_remarks, level_8_label, level_8_remarks, level_9_label, level_9_remarks)  from '$$PATH$$/2364.dat' ;
--
-- Data for Name: compile_lists; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY compile_lists (id, login_account_id, list_header_id, type, created_at, updated_at) FROM stdin;
\.
copy compile_lists (id, login_account_id, list_header_id, type, created_at, updated_at)  from '$$PATH$$/2354.dat' ;
--
-- Data for Name: contacts; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY contacts (id, pre_value, value, post_value, preferred_time, preferred_day, remarks, type, contactable_id, contactable_type, created_at, updated_at, monday_hours, tuesday_hours, wednesday_hours, thursday_hours, friday_hours, saturday_hours, sunday_hours, priority_number, contact_meta_type_id) FROM stdin;
\.
copy contacts (id, pre_value, value, post_value, preferred_time, preferred_day, remarks, type, contactable_id, contactable_type, created_at, updated_at, monday_hours, tuesday_hours, wednesday_hours, thursday_hours, friday_hours, saturday_hours, sunday_hours, priority_number, contact_meta_type_id)  from '$$PATH$$/2321.dat' ;
--
-- Data for Name: countries; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY countries (id, long_name, short_name, citizenship, capital, iso_code, currency, currency_subunit, main_language_id, created_at, updated_at, dialup_code) FROM stdin;
\.
copy countries (id, long_name, short_name, citizenship, capital, iso_code, currency, currency_subunit, main_language_id, created_at, updated_at, dialup_code)  from '$$PATH$$/2328.dat' ;
--
-- Data for Name: dashboard_preferences; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY dashboard_preferences (id, login_account_id, column_id, box_id) FROM stdin;
\.
copy dashboard_preferences (id, login_account_id, column_id, box_id)  from '$$PATH$$/2368.dat' ;
--
-- Data for Name: duplication_formula_details; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY duplication_formula_details (id, duplication_formula_id, table_name, field_name, number_of_charecter, created_at, updated_at, is_foreign_key) FROM stdin;
\.
copy duplication_formula_details (id, duplication_formula_id, table_name, field_name, number_of_charecter, created_at, updated_at, is_foreign_key)  from '$$PATH$$/2357.dat' ;
--
-- Data for Name: duplication_formulas; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY duplication_formulas (id, description, created_at, updated_at, duplication_space, type, "group", status) FROM stdin;
\.
copy duplication_formulas (id, description, created_at, updated_at, duplication_space, type, "group", status)  from '$$PATH$$/2356.dat' ;
--
-- Data for Name: employments; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY employments (id, person_id, organisation_id, sequence_no, staff_reference, position_reference, position_name, commenced_date, term_length, term_end_date, duties_resposibilities, hired_by, report_to, weekly_nominal_hours, hourly_rate, annual_base_salary, plus_package, award_other, suspension_start_date, suspension_end_date, suspended_by, suspension_reason, suspension_remarks, termination_notice_date, termination_date, terminated_by, termination_reason, termination_remarks, created_at, updated_at, status, department_id, section_id, cost_centre_id, position_title_id, position_classification_id, position_type_id, award_agreement_id, position_status_id, payment_frequency_id, payment_method_id, payment_day_id, suspension_type_id, termination_method_id) FROM stdin;
\.
copy employments (id, person_id, organisation_id, sequence_no, staff_reference, position_reference, position_name, commenced_date, term_length, term_end_date, duties_resposibilities, hired_by, report_to, weekly_nominal_hours, hourly_rate, annual_base_salary, plus_package, award_other, suspension_start_date, suspension_end_date, suspended_by, suspension_reason, suspension_remarks, termination_notice_date, termination_date, terminated_by, termination_reason, termination_remarks, created_at, updated_at, status, department_id, section_id, cost_centre_id, position_title_id, position_classification_id, position_type_id, award_agreement_id, position_status_id, payment_frequency_id, payment_method_id, payment_day_id, suspension_type_id, termination_method_id)  from '$$PATH$$/2337.dat' ;
--
-- Data for Name: feedback_items; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY feedback_items (id, login_account_id, subject, content, ip_address, status, feedback_date, created_at, updated_at, response, response_date, responded_to_by_id) FROM stdin;
\.
copy feedback_items (id, login_account_id, subject, content, ip_address, status, feedback_date, created_at, updated_at, response, response_date, responded_to_by_id)  from '$$PATH$$/2363.dat' ;
--
-- Data for Name: grids; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY grids (id, login_account_id, grid_object_id, type, field_1, field_2, field_3, field_4, field_5, field_6, field_7, field_8, field_9, field_10) FROM stdin;
\.
copy grids (id, login_account_id, grid_object_id, type, field_1, field_2, field_3, field_4, field_5, field_6, field_7, field_8, field_9, field_10)  from '$$PATH$$/2358.dat' ;
--
-- Data for Name: group_lists; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY group_lists (id, tag_id, list_header_id, created_at, updated_at) FROM stdin;
\.
copy group_lists (id, tag_id, list_header_id, created_at, updated_at)  from '$$PATH$$/2352.dat' ;
--
-- Data for Name: group_permissions; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY group_permissions (id, system_permission_type_id, user_group_id) FROM stdin;
\.
copy group_permissions (id, system_permission_type_id, user_group_id)  from '$$PATH$$/2353.dat' ;
--
-- Data for Name: groups; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY groups (id, tags_id, name, description, status, group_owner, start_date, end_date, created_at, updated_at) FROM stdin;
\.
copy groups (id, tags_id, name, description, status, group_owner, start_date, end_date, created_at, updated_at)  from '$$PATH$$/2346.dat' ;
--
-- Data for Name: images; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY images (id, image_file_data, image_filename, image_width, image_height, imageable_id, imageable_type, created_at, updated_at) FROM stdin;
\.
copy images (id, image_file_data, image_filename, image_width, image_height, imageable_id, imageable_type, created_at, updated_at)  from '$$PATH$$/2331.dat' ;
--
-- Data for Name: keyword_links; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY keyword_links (id, keyword_id, taggable_id, taggable_type, created_at, updated_at) FROM stdin;
\.
copy keyword_links (id, keyword_id, taggable_id, taggable_type, created_at, updated_at)  from '$$PATH$$/2325.dat' ;
--
-- Data for Name: keywords; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY keywords (id, name, keyword_type_id, created_at, updated_at, status, description, to_be_removed) FROM stdin;
\.
copy keywords (id, name, keyword_type_id, created_at, updated_at, status, description, to_be_removed)  from '$$PATH$$/2324.dat' ;
--
-- Data for Name: languages; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY languages (id, name, created_at, updated_at) FROM stdin;
\.
copy languages (id, name, created_at, updated_at)  from '$$PATH$$/2322.dat' ;
--
-- Data for Name: list_details; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY list_details (id, list_header_id, person_id, created_at, updated_at) FROM stdin;
\.
copy list_details (id, list_header_id, person_id, created_at, updated_at)  from '$$PATH$$/2350.dat' ;
--
-- Data for Name: list_headers; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY list_headers (id, type, name, description, list_size, last_date_generated, status, created_at, updated_at, source, source_type, allow_duplication, top_type, top_value, login_account_id) FROM stdin;
\.
copy list_headers (id, type, name, description, list_size, last_date_generated, status, created_at, updated_at, source, source_type, allow_duplication, top_type, top_value, login_account_id)  from '$$PATH$$/2349.dat' ;
--
-- Data for Name: login_accounts; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY login_accounts (id, person_id, user_name, password_hash, password_salt, security_email, password_hint, question1_answer, question2_answer, question3_answer, password_last_hash, password_last_salt, password_last_date, last_login, last_logoff, last_ip_address, session_timeout, authentication_token, authentication_grace_period, login_status, system_user, security_question1_id, security_question2_id, security_question3_id, access_attempt_ip, access_attempts_count, password_by_admin, password_lifetime, type, password_updated_at, created_at, updated_at, online_status) FROM stdin;
\.
copy login_accounts (id, person_id, user_name, password_hash, password_salt, security_email, password_hint, question1_answer, question2_answer, question3_answer, password_last_hash, password_last_salt, password_last_date, last_login, last_logoff, last_ip_address, session_timeout, authentication_token, authentication_grace_period, login_status, system_user, security_question1_id, security_question2_id, security_question3_id, access_attempt_ip, access_attempts_count, password_by_admin, password_lifetime, type, password_updated_at, created_at, updated_at, online_status)  from '$$PATH$$/2342.dat' ;
--
-- Data for Name: master_docs; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY master_docs (id, doc_number, doc_reference, security_number, category, long_name, short_name, name_on_doc, other_on_doc, issue_person, issue_organisation, issue_place, issue_state, action_taken, remarks, issue_date, expiry_date, reminder, master_doc_type_id, entity_id, entity_type, created_at, updated_at, priority_number, issue_country_id) FROM stdin;
\.
copy master_docs (id, doc_number, doc_reference, security_number, category, long_name, short_name, name_on_doc, other_on_doc, issue_person, issue_organisation, issue_place, issue_state, action_taken, remarks, issue_date, expiry_date, reminder, master_doc_type_id, entity_id, entity_type, created_at, updated_at, priority_number, issue_country_id)  from '$$PATH$$/2327.dat' ;
--
-- Data for Name: message_templates; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY message_templates (id, name, body, created_at, updated_at) FROM stdin;
\.
copy message_templates (id, name, body, created_at, updated_at)  from '$$PATH$$/2381.dat' ;
--
-- Data for Name: notes; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY notes (id, label, short_description, alarm_date, alarm_time, active, body_text, noteable_id, noteable_type, note_type_id, created_at, updated_at) FROM stdin;
\.
copy notes (id, label, short_description, alarm_date, alarm_time, active, body_text, noteable_id, noteable_type, note_type_id, created_at, updated_at)  from '$$PATH$$/2326.dat' ;
--
-- Data for Name: organisation_groups; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY organisation_groups (id, organisation_id, tag_id, created_at, updated_at) FROM stdin;
\.
copy organisation_groups (id, organisation_id, tag_id, created_at, updated_at)  from '$$PATH$$/2359.dat' ;
--
-- Data for Name: organisation_hierarchies; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY organisation_hierarchies (id, hierarchy_level, hierarchy_name, remarks, created_at, updated_at) FROM stdin;
\.
copy organisation_hierarchies (id, hierarchy_level, hierarchy_name, remarks, created_at, updated_at)  from '$$PATH$$/2333.dat' ;
--
-- Data for Name: organisation_key_personnels; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY organisation_key_personnels (id, organisation_id, person_id, designation, remarks, created_at, updated_at) FROM stdin;
\.
copy organisation_key_personnels (id, organisation_id, person_id, designation, remarks, created_at, updated_at)  from '$$PATH$$/2334.dat' ;
--
-- Data for Name: organisation_relationships; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY organisation_relationships (id, source_organisation_id, related_organisation_id, remarks, created_at, updated_at) FROM stdin;
\.
copy organisation_relationships (id, source_organisation_id, related_organisation_id, remarks, created_at, updated_at)  from '$$PATH$$/2383.dat' ;
--
-- Data for Name: organisation_subsidiaries; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY organisation_subsidiaries (id, parent_id, organisation_id, remarks, created_at, updated_at) FROM stdin;
\.
copy organisation_subsidiaries (id, parent_id, organisation_id, remarks, created_at, updated_at)  from '$$PATH$$/2335.dat' ;
--
-- Data for Name: organisations; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY organisations (id, custom_id, full_name, short_name, trading_as, registered_name, registered_number, registered_date, registered_country_id, tax_file_no, legal_no_1, legal_no_2, industrial_code, number_of_full_time_employees, number_of_part_time_employees, number_of_contractors, number_of_volunteers, number_of_other_workers, business_mission, organisation_hierarchy_id, remarks, created_at, updated_at, organisation_type_id, business_type_id, industry_sector_id, business_category_id, onrecord_since, business_sub_category, duplication_value, type, created_by_id, updated_by_id, level, level_label) FROM stdin;
\.
copy organisations (id, custom_id, full_name, short_name, trading_as, registered_name, registered_number, registered_date, registered_country_id, tax_file_no, legal_no_1, legal_no_2, industrial_code, number_of_full_time_employees, number_of_part_time_employees, number_of_contractors, number_of_volunteers, number_of_other_workers, business_mission, organisation_hierarchy_id, remarks, created_at, updated_at, organisation_type_id, business_type_id, industry_sector_id, business_category_id, onrecord_since, business_sub_category, duplication_value, type, created_by_id, updated_by_id, level, level_label)  from '$$PATH$$/2332.dat' ;
--
-- Data for Name: people; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY people (id, custom_id, primary_title_id, second_title_id, first_name, middle_name, family_name, maiden_name, preferred_name, initials, post_title, birth_date, primary_salutation, second_salutation, industry_sector_id, interests, origin_country_id, residence_country_id, nationality_id, other_nationality_id, language_id, other_language_id, religion_id, onrecord_since, created_at, updated_at, marital_status_id, gender_id, duplication_value) FROM stdin;
\.
copy people (id, custom_id, primary_title_id, second_title_id, first_name, middle_name, family_name, maiden_name, preferred_name, initials, post_title, birth_date, primary_salutation, second_salutation, industry_sector_id, interests, origin_country_id, residence_country_id, nationality_id, other_nationality_id, language_id, other_language_id, religion_id, onrecord_since, created_at, updated_at, marital_status_id, gender_id, duplication_value)  from '$$PATH$$/2319.dat' ;
--
-- Data for Name: person_bank_accounts; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY person_bank_accounts (id, person_id, bank_id, account_number, account_type_id, status, remarks) FROM stdin;
\.
copy person_bank_accounts (id, person_id, bank_id, account_number, account_type_id, status, remarks)  from '$$PATH$$/2376.dat' ;
--
-- Data for Name: person_groups; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY person_groups (id, people_id, tag_id, created_at, updated_at) FROM stdin;
\.
copy person_groups (id, people_id, tag_id, created_at, updated_at)  from '$$PATH$$/2348.dat' ;
--
-- Data for Name: person_roles; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY person_roles (id, person_id, role_id, remarks, created_at, updated_at, sequence_no, assigned_by, approved_by, assignment_date, start_date, end_date, supervised_by, managed_by) FROM stdin;
\.
copy person_roles (id, person_id, role_id, remarks, created_at, updated_at, sequence_no, assigned_by, approved_by, assignment_date, start_date, end_date, supervised_by, managed_by)  from '$$PATH$$/2330.dat' ;
--
-- Data for Name: post_areas; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY post_areas (id, country_id, division_name, remarks, type, created_at, updated_at) FROM stdin;
\.
copy post_areas (id, country_id, division_name, remarks, type, created_at, updated_at)  from '$$PATH$$/2369.dat' ;
--
-- Data for Name: postcodes; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY postcodes (id, country_id, governance, province, state, region, district, zone, city, town, suburb, postcode, mail_code, bulk_code, geographical_area_id, electoral_area_id) FROM stdin;
\.
copy postcodes (id, country_id, governance, province, state, region, district, zone, city, town, suburb, postcode, mail_code, bulk_code, geographical_area_id, electoral_area_id)  from '$$PATH$$/2355.dat' ;
--
-- Data for Name: potential_members; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY potential_members (id, first_name, family_name, email) FROM stdin;
\.
copy potential_members (id, first_name, family_name, email)  from '$$PATH$$/2385.dat' ;
--
-- Data for Name: query_criterias; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY query_criterias (id, query_header_id, sequence, table_name, field_name, data_type, operator, option, value, status) FROM stdin;
\.
copy query_criterias (id, query_header_id, sequence, table_name, field_name, data_type, operator, option, value, status)  from '$$PATH$$/2345.dat' ;
--
-- Data for Name: query_details; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY query_details (id, query_header_id, sequence, table_name, field_name, status, type, ascending, data_type) FROM stdin;
\.
copy query_details (id, query_header_id, sequence, table_name, field_name, status, type, ascending, data_type)  from '$$PATH$$/2344.dat' ;
--
-- Data for Name: query_headers; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY query_headers (id, name, description, last_date_executed, result_size, status, created_at, updated_at, "group", created_by_id, updated_by_id, top_value, top_type, allow_duplication) FROM stdin;
\.
copy query_headers (id, name, description, last_date_executed, result_size, status, created_at, updated_at, "group", created_by_id, updated_by_id, top_value, top_type, allow_duplication)  from '$$PATH$$/2343.dat' ;
--
-- Data for Name: receipt_accounts; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY receipt_accounts (id, name, description, post_to_history, post_to_campaign, send_receipt, status, remarks, created_at, updated_at, link_module_id, link_module_name) FROM stdin;
\.
copy receipt_accounts (id, name, description, post_to_history, post_to_campaign, send_receipt, status, remarks, created_at, updated_at, link_module_id, link_module_name)  from '$$PATH$$/2373.dat' ;
--
-- Data for Name: receipt_methods; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY receipt_methods (id, name, description, receipt_method_type_id, status, remarks, card_merchant_number, card_name, card_location, card_cost, card_floor_limit, card_lines_per_page, created_at, updated_at) FROM stdin;
\.
copy receipt_methods (id, name, description, receipt_method_type_id, status, remarks, card_merchant_number, card_name, card_location, card_cost, card_floor_limit, card_lines_per_page, created_at, updated_at)  from '$$PATH$$/2374.dat' ;
--
-- Data for Name: relationships; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY relationships (id, source_person_id, related_person_id, relationship_type_id, created_at, updated_at) FROM stdin;
\.
copy relationships (id, source_person_id, related_person_id, relationship_type_id, created_at, updated_at)  from '$$PATH$$/2323.dat' ;
--
-- Data for Name: role_conditions; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY role_conditions (id, role_id, priority_number, doctype_id, remarks, created_at, updated_at) FROM stdin;
\.
copy role_conditions (id, role_id, priority_number, doctype_id, remarks, created_at, updated_at)  from '$$PATH$$/2338.dat' ;
--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY roles (id, name, role_type_id, created_at, updated_at, description, remarks, role_status, to_be_removed) FROM stdin;
\.
copy roles (id, name, role_type_id, created_at, updated_at, description, remarks, role_status, to_be_removed)  from '$$PATH$$/2329.dat' ;
--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY schema_migrations (version) FROM stdin;
\.
copy schema_migrations (version)  from '$$PATH$$/2318.dat' ;
--
-- Data for Name: simple_captcha_data; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY simple_captcha_data (id, key, value, created_at, updated_at) FROM stdin;
\.
copy simple_captcha_data (id, key, value, created_at, updated_at)  from '$$PATH$$/2362.dat' ;
--
-- Data for Name: sources; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY sources (id, campaign_id, name, description, volume, cost, dead_return, letter_id, account_code_id, status, remarks, created_at, updated_at) FROM stdin;
\.
copy sources (id, campaign_id, name, description, volume, cost, dead_return, letter_id, account_code_id, status, remarks, created_at, updated_at)  from '$$PATH$$/2372.dat' ;
--
-- Data for Name: system_logs; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY system_logs (id, login_account_id, message, controller, action, ip_address, created_at, updated_at, status) FROM stdin;
\.
copy system_logs (id, login_account_id, message, controller, action, ip_address, created_at, updated_at, status)  from '$$PATH$$/2366.dat' ;
--
-- Data for Name: system_news; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY system_news (id, description, event_date, created_by_id, updated_by_id, created_at, updated_at, title, status) FROM stdin;
\.
copy system_news (id, description, event_date, created_by_id, updated_by_id, created_at, updated_at, title, status)  from '$$PATH$$/2360.dat' ;
--
-- Data for Name: tag_meta_types; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY tag_meta_types (id, name, description, "position", status, type, created_at, updated_at, category, to_be_removed) FROM stdin;
\.
copy tag_meta_types (id, name, description, "position", status, type, created_at, updated_at, category, to_be_removed)  from '$$PATH$$/2339.dat' ;
--
-- Data for Name: tag_types; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY tag_types (id, name, tag_meta_type_id, description, "position", status, type, created_at, updated_at, category, to_be_removed) FROM stdin;
\.
copy tag_types (id, name, tag_meta_type_id, description, "position", status, type, created_at, updated_at, category, to_be_removed)  from '$$PATH$$/2340.dat' ;
--
-- Data for Name: tags; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY tags (id, name, tag_type_id, description, "position", status, type, created_at, updated_at, category, to_be_removed) FROM stdin;
\.
copy tags (id, name, tag_type_id, description, "position", status, type, created_at, updated_at, category, to_be_removed)  from '$$PATH$$/2341.dat' ;
--
-- Data for Name: to_do_lists; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY to_do_lists (id, description, status, due_date, created_by_id, updated_by_id, login_account_id, created_at, updated_at) FROM stdin;
\.
copy to_do_lists (id, description, status, due_date, created_by_id, updated_by_id, login_account_id, created_at, updated_at)  from '$$PATH$$/2361.dat' ;
--
-- Data for Name: transaction_allocations; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY transaction_allocations (id, transaction_header_id, receipt_account_id, campaign_id, source_id, amount, letter_id, letter_sent, date_sent, extention_id, extention_type, cluster_id, cluster_type, created_at, updated_at) FROM stdin;
\.
copy transaction_allocations (id, transaction_header_id, receipt_account_id, campaign_id, source_id, amount, letter_id, letter_sent, date_sent, extention_id, extention_type, cluster_id, cluster_type, created_at, updated_at)  from '$$PATH$$/2380.dat' ;
--
-- Data for Name: transaction_headers; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY transaction_headers (id, entity_id, entity_type, todays_date, transaction_date, receipt_meta_type_id, receipt_meta_type_name, receipt_type_id, receipt_type_name, bank_account_id, bank_account_name, bank_run_id, receipt_number, letter_id, letter_sent, date_sent, total_amount, notes, received_via_id, received_via_name, banked, created_at, updated_at) FROM stdin;
\.
copy transaction_headers (id, entity_id, entity_type, todays_date, transaction_date, receipt_meta_type_id, receipt_meta_type_name, receipt_type_id, receipt_type_name, bank_account_id, bank_account_name, bank_run_id, receipt_number, letter_id, letter_sent, date_sent, total_amount, notes, received_via_id, received_via_name, banked, created_at, updated_at)  from '$$PATH$$/2379.dat' ;
--
-- Data for Name: transaction_type_details; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY transaction_type_details (id, transaction_header_id, type, name_on_cheque, cheque_number, date_on_cheque, name_on_card, card_number, expire_month, expire_year, cvv_number, created_at, updated_at, bank_id) FROM stdin;
\.
copy transaction_type_details (id, transaction_header_id, type, name_on_cheque, cheque_number, date_on_cheque, name_on_card, card_number, expire_month, expire_year, cvv_number, created_at, updated_at, bank_id)  from '$$PATH$$/2384.dat' ;
--
-- Data for Name: user_groups; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY user_groups (id, user_id, group_id) FROM stdin;
\.
copy user_groups (id, user_id, group_id)  from '$$PATH$$/2347.dat' ;
--
-- Data for Name: user_lists; Type: TABLE DATA; Schema: public; Owner: rails
--

COPY user_lists (id, user_id, list_header_id) FROM stdin;
\.
copy user_lists (id, user_id, list_header_id)  from '$$PATH$$/2351.dat' ;
--
-- Name: addresses_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY addresses
    ADD CONSTRAINT addresses_pkey PRIMARY KEY (id);


--
-- Name: allocation_types_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY allocation_types
    ADD CONSTRAINT allocation_types_pkey PRIMARY KEY (id);


--
-- Name: amazon_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY amazon_settings
    ADD CONSTRAINT amazon_settings_pkey PRIMARY KEY (id);


--
-- Name: available_modules_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY available_modules
    ADD CONSTRAINT available_modules_pkey PRIMARY KEY (id);


--
-- Name: bank_grids_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY bank_grids
    ADD CONSTRAINT bank_grids_pkey PRIMARY KEY (id);


--
-- Name: banks_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY banks
    ADD CONSTRAINT banks_pkey PRIMARY KEY (id);


--
-- Name: bdrb_job_queues_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY bdrb_job_queues
    ADD CONSTRAINT bdrb_job_queues_pkey PRIMARY KEY (id);


--
-- Name: bulk_emails_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY bulk_emails
    ADD CONSTRAINT bulk_emails_pkey PRIMARY KEY (id);


--
-- Name: campaigns_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY campaigns
    ADD CONSTRAINT campaigns_pkey PRIMARY KEY (id);


--
-- Name: client_bank_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY bank_accounts
    ADD CONSTRAINT client_bank_accounts_pkey PRIMARY KEY (id);


--
-- Name: client_setups_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY client_setups
    ADD CONSTRAINT client_setups_pkey PRIMARY KEY (id);


--
-- Name: compile_lists_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY compile_lists
    ADD CONSTRAINT compile_lists_pkey PRIMARY KEY (id);


--
-- Name: contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY contacts
    ADD CONSTRAINT contacts_pkey PRIMARY KEY (id);


--
-- Name: countries_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY countries
    ADD CONSTRAINT countries_pkey PRIMARY KEY (id);


--
-- Name: dashboard_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY dashboard_preferences
    ADD CONSTRAINT dashboard_preferences_pkey PRIMARY KEY (id);


--
-- Name: duplication_formula_details_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY duplication_formula_details
    ADD CONSTRAINT duplication_formula_details_pkey PRIMARY KEY (id);


--
-- Name: duplication_formulas_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY duplication_formulas
    ADD CONSTRAINT duplication_formulas_pkey PRIMARY KEY (id);


--
-- Name: employments_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY employments
    ADD CONSTRAINT employments_pkey PRIMARY KEY (id);


--
-- Name: feedback_items_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY feedback_items
    ADD CONSTRAINT feedback_items_pkey PRIMARY KEY (id);


--
-- Name: grids_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY grids
    ADD CONSTRAINT grids_pkey PRIMARY KEY (id);


--
-- Name: group_lists_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY group_lists
    ADD CONSTRAINT group_lists_pkey PRIMARY KEY (id);


--
-- Name: group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY group_permissions
    ADD CONSTRAINT group_permissions_pkey PRIMARY KEY (id);


--
-- Name: groups_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY groups
    ADD CONSTRAINT groups_pkey PRIMARY KEY (id);


--
-- Name: images_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY images
    ADD CONSTRAINT images_pkey PRIMARY KEY (id);


--
-- Name: keyword_links_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY keyword_links
    ADD CONSTRAINT keyword_links_pkey PRIMARY KEY (id);


--
-- Name: keywords_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY keywords
    ADD CONSTRAINT keywords_pkey PRIMARY KEY (id);


--
-- Name: languages_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY languages
    ADD CONSTRAINT languages_pkey PRIMARY KEY (id);


--
-- Name: list_details_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY list_details
    ADD CONSTRAINT list_details_pkey PRIMARY KEY (id);


--
-- Name: list_headers_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY list_headers
    ADD CONSTRAINT list_headers_pkey PRIMARY KEY (id);


--
-- Name: login_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY login_accounts
    ADD CONSTRAINT login_accounts_pkey PRIMARY KEY (id);


--
-- Name: master_docs_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY master_docs
    ADD CONSTRAINT master_docs_pkey PRIMARY KEY (id);


--
-- Name: message_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY message_templates
    ADD CONSTRAINT message_templates_pkey PRIMARY KEY (id);


--
-- Name: notes_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY notes
    ADD CONSTRAINT notes_pkey PRIMARY KEY (id);


--
-- Name: organisation_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY organisation_groups
    ADD CONSTRAINT organisation_groups_pkey PRIMARY KEY (id);


--
-- Name: organisation_hierarchies_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY organisation_hierarchies
    ADD CONSTRAINT organisation_hierarchies_pkey PRIMARY KEY (id);


--
-- Name: organisation_key_personnels_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY organisation_key_personnels
    ADD CONSTRAINT organisation_key_personnels_pkey PRIMARY KEY (id);


--
-- Name: organisation_relationships_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY organisation_relationships
    ADD CONSTRAINT organisation_relationships_pkey PRIMARY KEY (id);


--
-- Name: organisation_subsidiaries_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY organisation_subsidiaries
    ADD CONSTRAINT organisation_subsidiaries_pkey PRIMARY KEY (id);


--
-- Name: organisations_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY organisations
    ADD CONSTRAINT organisations_pkey PRIMARY KEY (id);


--
-- Name: people_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY people
    ADD CONSTRAINT people_pkey PRIMARY KEY (id);


--
-- Name: person_bank_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY person_bank_accounts
    ADD CONSTRAINT person_bank_accounts_pkey PRIMARY KEY (id);


--
-- Name: person_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY person_groups
    ADD CONSTRAINT person_groups_pkey PRIMARY KEY (id);


--
-- Name: person_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY person_roles
    ADD CONSTRAINT person_roles_pkey PRIMARY KEY (id);


--
-- Name: post_areas_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY post_areas
    ADD CONSTRAINT post_areas_pkey PRIMARY KEY (id);


--
-- Name: postcodes_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY postcodes
    ADD CONSTRAINT postcodes_pkey PRIMARY KEY (id);


--
-- Name: potential_members_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY potential_members
    ADD CONSTRAINT potential_members_pkey PRIMARY KEY (id);


--
-- Name: query_criterias_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY query_criterias
    ADD CONSTRAINT query_criterias_pkey PRIMARY KEY (id);


--
-- Name: query_details_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY query_details
    ADD CONSTRAINT query_details_pkey PRIMARY KEY (id);


--
-- Name: query_headers_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY query_headers
    ADD CONSTRAINT query_headers_pkey PRIMARY KEY (id);


--
-- Name: receipt_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY receipt_accounts
    ADD CONSTRAINT receipt_accounts_pkey PRIMARY KEY (id);


--
-- Name: receipt_methods_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY receipt_methods
    ADD CONSTRAINT receipt_methods_pkey PRIMARY KEY (id);


--
-- Name: relationships_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY relationships
    ADD CONSTRAINT relationships_pkey PRIMARY KEY (id);


--
-- Name: role_conditions_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY role_conditions
    ADD CONSTRAINT role_conditions_pkey PRIMARY KEY (id);


--
-- Name: roles_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: simple_captcha_data_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY simple_captcha_data
    ADD CONSTRAINT simple_captcha_data_pkey PRIMARY KEY (id);


--
-- Name: sources_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY sources
    ADD CONSTRAINT sources_pkey PRIMARY KEY (id);


--
-- Name: system_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY system_logs
    ADD CONSTRAINT system_logs_pkey PRIMARY KEY (id);


--
-- Name: system_news_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY system_news
    ADD CONSTRAINT system_news_pkey PRIMARY KEY (id);


--
-- Name: tag_meta_types_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY tag_meta_types
    ADD CONSTRAINT tag_meta_types_pkey PRIMARY KEY (id);


--
-- Name: tag_types_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY tag_types
    ADD CONSTRAINT tag_types_pkey PRIMARY KEY (id);


--
-- Name: tags_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY tags
    ADD CONSTRAINT tags_pkey PRIMARY KEY (id);


--
-- Name: to_do_lists_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY to_do_lists
    ADD CONSTRAINT to_do_lists_pkey PRIMARY KEY (id);


--
-- Name: transaction_allocations_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY transaction_allocations
    ADD CONSTRAINT transaction_allocations_pkey PRIMARY KEY (id);


--
-- Name: transaction_headers_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY transaction_headers
    ADD CONSTRAINT transaction_headers_pkey PRIMARY KEY (id);


--
-- Name: transaction_type_details_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY transaction_type_details
    ADD CONSTRAINT transaction_type_details_pkey PRIMARY KEY (id);


--
-- Name: user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY user_groups
    ADD CONSTRAINT user_groups_pkey PRIMARY KEY (id);


--
-- Name: user_lists_pkey; Type: CONSTRAINT; Schema: public; Owner: rails; Tablespace: 
--

ALTER TABLE ONLY user_lists
    ADD CONSTRAINT user_lists_pkey PRIMARY KEY (id);


--
-- Name: unique_schema_migrations; Type: INDEX; Schema: public; Owner: rails; Tablespace: 
--

CREATE UNIQUE INDEX unique_schema_migrations ON schema_migrations USING btree (version);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

